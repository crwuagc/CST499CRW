<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_information";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_id = $_SESSION['student_id'];

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['courseID'])) {
    $courseID = $_POST['courseID'];

    $check_sql = "SELECT * FROM tblRegistration WHERE student_id = ? AND courseID = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("ss", $student_id, $courseID);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        $message = "You are already registered for this course.";
    } else {
        $insert_sql = "INSERT INTO tblRegistration (student_id, courseID) VALUES (?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("ss", $student_id, $courseID);

        if ($insert_stmt->execute()) {
            $message = "Successfully registered for course ID: $courseID!";
        } else {
            $message = "Error registering for course.";
        }

        $insert_stmt->close();
    }

    $check_stmt->close();
}

$sql = "SELECT courseName, courseID, coursePrefix, courseStartDate, courseCost FROM tblCourse";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register for Classes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: "Times New Roman", Times;
            background: rgb(32, 32, 32);
            color: white;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        header {
            background-color: rgb(84, 47, 119);
            padding: 40px 0;
        }

        h2 {
            margin-top: 40px;
        }

        table {
            width: 85%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: rgb(50, 50, 50);
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid rgb(84, 47, 119);
        }

        th {
            background-color: rgb(84, 47, 119);
            color: white;
        }

        tr:hover {
            background-color: rgb(60, 60, 60);
        }

        button {
            padding: 8px 16px;
            background-color: rgb(84, 47, 119);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }

        button:hover {
            background-color: rgb(130, 90, 175);
        }

        a.back {
            display: inline-block;
            margin: 20px;
            padding: 10px 20px;
            background-color: rgb(84, 47, 119);
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: background-color 0.3s;
        }

        a.back:hover {
            background-color: rgb(130, 90, 175);
        }

        .message {
            margin-top: 20px;
            font-weight: bold;
            color: rgb(150, 200, 255);
        }

        footer {
            background-color: black;
            color: white;
            padding: 10px;
            font-size: 14px;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <header>
        <h1>CST499 Course Registration</h1>
    </header>

    <h2>Available Courses</h2>

    <?php if (isset($message)): ?>
        <div class="message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <?php
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Course Name</th><th>Course ID</th><th>Prefix</th><th>Start Date</th><th>Cost ($)</th><th>Action</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row["courseName"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["courseID"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["coursePrefix"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["courseStartDate"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["courseCost"]) . "</td>";
            echo "<td>
                    <form method='POST' action=''>
                        <input type='hidden' name='courseID' value='" . htmlspecialchars($row["courseID"]) . "'>
                        <button type='submit'>Register</button>
                    </form>
                  </td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p>No courses available.</p>";
    }

    $conn->close();
    ?>

    <a href="student_index.php" class="back">Back to Portal</a>

    <footer>
        &copy; <?php echo date("Y"); ?> CST499Wakim.
    </footer>
</body>
</html>