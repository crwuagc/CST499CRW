<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: "Times New Roman", Times;
            background: rgb(32, 32, 32);
            margin: 0;
            padding: 0;
            font-size: 15px;
            color: white;
            text-align: center;
        }

        header {
            background-color: rgb(84, 47, 119);
            color: white;
            padding: 40px 0;
        }

        nav {
            background-color: rgb(84, 47, 119);
            padding: 10px 0;
            margin-top: 280px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 25px;
            font-weight: bold;
            font-size: 18px;
        }

        nav a:hover {
            text-decoration: underline;
            color: black;
        }

        .container {
            padding: 200px 20px;
        }

        .button-container {
            margin-top: 40px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }

        .button-container a {
            display: block;
            width: 220px;
            padding: 12px 24px;
            background-color: rgb(84, 47, 119);
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 8px;
            transition: background-color 0.3s;
        }

        .button-container a:hover {
            background-color: rgb(130, 90, 175);
        }

        footer {
            margin-top: 0px;
            padding: 10px;
            background-color: rgb(0, 0, 0);
            color: white;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to the CST499 Student Portal</h1>
    </header>

    <div class="container">
        <p>Login Successful</p>

        <div class="button-container">
            <a href="register_classes.php">Register for Classes</a>
            <a href="my_classes.php">My Registered Classes</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <footer>
        &copy; <?php echo date("Y"); ?> CST499Wakim.
    </footer>
</body>
</html>