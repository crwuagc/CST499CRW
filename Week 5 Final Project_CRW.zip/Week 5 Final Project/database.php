<?php

class Database {
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "student_information";
    public $connection;

    public function __construct() {
        $this->connection = new mysqli(
            $this->host, $this->username, $this->password, $this->database
        );

        if ($this->connection->connect_error) {
            die("Connection Unsuccessful: " . $this->connection->connect_error);
        }
    }

    public function executeSelectQuery($con, $sql) {
        $result = $con->query($sql);

        if ($result === false) {
            echo "Error: " . $con->error;
            return null;
        }

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    }

    public function executeQuery($con, $sql) {
        if ($con->query($sql) === true) {
            return true;
        } else {
            echo "Error: " . $con->error;
            return false;
        }
    }
}