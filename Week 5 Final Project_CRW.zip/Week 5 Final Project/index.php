<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: "Times New Roman", Times;
            background:rgb(32, 32, 32);
            margin: 0;
            padding: 0;
            font-size: 15px;
            color: white;
            text-align: center;
        }

        header {
            background-color:rgb(84, 47, 119);
            color: white;
            padding: 40px 0;
        }

        nav {
            background-color:rgb(84, 47, 119);
            padding: 10px 0;
            margin-top: 280px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 25px;
            font-weight: bold;
            font-size: 18px; 
        }

        nav a:hover {
            text-decoration: underline;
            color: black;
        }

        .container {
            padding: 200px 20px;
        }

        footer {
            margin-top: 0px;
            padding: 10px;
            background-color: rgb(0, 0, 0);
            color: white;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <?php ?>

    <header>
        <h1>Welcome to the CST499 University Hub</h1>
    </header>

    <div class="container">
        <p>This is the landing page which contains links to the Login and Enrollment pages.</p>
    </div>

    <nav>
        <a href="/login.php">Login</a>
        <a href="/enrollment.php">Enrollment</a>
    </nav>

    <footer>
        &copy; <?php echo date("Y"); ?> CST499Wakim.
    </footer>
</body>
</html>