<?php
session_start();

if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_information";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['remove_courseID'])) {
    $removeCourseID = $_POST['remove_courseID'];

    $delete_sql = "DELETE FROM tblRegistration WHERE student_id = ? AND courseID = ?";
    $stmt_delete = $conn->prepare($delete_sql);
    $stmt_delete->bind_param("ss", $student_id, $removeCourseID);

    if ($stmt_delete->execute()) {
        $message = "Successfully removed course ID: $removeCourseID";
    } else {
        $message = "Error removing course ID: $removeCourseID";
    }

    $stmt_delete->close();
}

$sql = "
    SELECT c.courseName, c.courseID, c.coursePrefix, c.courseStartDate, c.courseCost
    FROM tblRegistration r
    JOIN tblCourse c ON r.courseID = c.courseID
    WHERE r.student_id = ?
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Registered Classes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: "Times New Roman", Times;
            background: rgb(32, 32, 32);
            color: white;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        header {
            background-color: rgb(84, 47, 119);
            padding: 40px 0;
        }

        h2 {
            margin-top: 40px;
        }

        table {
            width: 85%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: rgb(50, 50, 50);
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            border-bottom: 1px solid rgb(84, 47, 119);
        }

        th {
            background-color: rgb(84, 47, 119);
            color: white;
        }

        tr:hover {
            background-color: rgb(60, 60, 60);
        }

        button {
            padding: 6px 14px;
            background-color: rgb(200, 50, 50);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        button:hover {
            background-color: rgb(255, 80, 80);
        }

        a.back {
            display: inline-block;
            margin: 20px;
            padding: 10px 20px;
            background-color: rgb(84, 47, 119);
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: background-color 0.3s;
        }

        a.back:hover {
            background-color: rgb(130, 90, 175);
        }

        .message {
            margin-top: 20px;
            font-weight: bold;
            color: rgb(255, 180, 180);
        }

        footer {
            background-color: black;
            color: white;
            padding: 10px;
            font-size: 14px;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <header>
        <h1>CST499 Enrollments</h1>
    </header>

    <h2>Enrolled Courses</h2>

    <?php if (isset($message)): ?>
        <div class="message"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <?php
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Course Name</th><th>Course ID</th><th>Prefix</th><th>Start Date</th><th>Cost ($)</th><th>Action</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['courseName']) . "</td>";
            echo "<td>" . htmlspecialchars($row['courseID']) . "</td>";
            echo "<td>" . htmlspecialchars($row['coursePrefix']) . "</td>";
            echo "<td>" . htmlspecialchars($row['courseStartDate']) . "</td>";
            echo "<td>" . htmlspecialchars($row['courseCost']) . "</td>";
            echo "<td>
                    <form method='POST' action='' onsubmit='return confirm(\"Are you sure you want to remove this course?\");'>
                        <input type='hidden' name='remove_courseID' value='" . htmlspecialchars($row['courseID']) . "'>
                        <button type='submit'>Remove</button>
                    </form>
                  </td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p>You have not registered for any courses yet.</p>";
    }

    $stmt->close();
    $conn->close();
    ?>

    <a href="student_index.php" class="back">Back to Portal</a>

    <footer>
        &copy; <?php echo date("Y"); ?> CST499Wakim.
    </footer>
</body>
</html>