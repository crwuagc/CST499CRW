<?php
session_start();

$_SESSION = [];
session_unset();
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logout - Student Portal</title>
    <style>
        body {
            font-family: "Times New Roman", Times;
            background: rgb(32, 32, 32);
            margin: 0;
            padding: 0;
            font-size: 15px;
            color: white;
            text-align: center;
        }

        header {
            background-color: rgb(84, 47, 119);
            color: white;
            padding: 40px 0;
        }

        nav {
            background-color: rgb(84, 47, 119);
            padding: 10px 0;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 25px;
            font-weight: bold;
            font-size: 18px;
        }

        nav a:hover {
            text-decoration: underline;
            color: black;
        }

        .container {
            padding: 100px 20px;
        }

        .logout-message {
            max-width: 500px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.1);
            padding: 30px;
            border-radius: 8px;
        }

        .logout-message a {
            display: inline-block;
            margin-top: 20px;
            background-color: rgb(84, 47, 119);
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
        }

        .logout-message a:hover {
            background-color: rgb(64, 35, 90);
        }

        footer {
            margin-top: 0px;
            padding: 10px;
            background-color: rgb(0, 0, 0);
            color: white;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
        <h1>CST499 Student Portal - Logout</h1>
    </header>
    <nav>
        <a href="/index.php">Landing Page</a>
    </nav>
    <div class="container">
        <div class="logout-message">
            <h2>Logout Successful</h2>
            <p>Thank you for choosing the CST499 Student Portal.</p>
            <a href="/login.php">Login</a>
        </div>
    </div>
    <footer>
        &copy; <?php echo date("Y"); ?> CST499Wakim.
    </footer>
</body>
</html>