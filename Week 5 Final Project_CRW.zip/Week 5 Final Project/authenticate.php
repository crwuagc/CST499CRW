<?php
session_start();
require_once 'Database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $db = new Database();
    $con = $db->connection;

    $stmt = $con->prepare("SELECT * FROM tblstudent WHERE Email_Address = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if ($password === $user['Password']) {
            $_SESSION['user_email'] = $email;
            $_SESSION['student_id'] = $user['id'];
            header("Location: student_index.php");
            exit();
        } else {
            header("Location: login.php?error=1");
            exit();
        }
    } else {
        header("Location: login.php?error=1");
        exit();
    }

    $stmt->close();
    $con->close();
} else {
    header("Location: login.php");
    exit();
}
?>