<?php require_once 'database.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enrollment - University Hub</title>
    <style>
        body {
            font-family: "Times New Roman", Times;
            background: rgb(32, 32, 32);
            margin: 0;
            padding: 0;
            font-size: 15px;
            color: white;
            text-align: center;
        }

        header {
            background-color: rgb(84, 47, 119);
            color: white;
            padding: 40px 0;
        }

        nav {
            background-color: rgb(84, 47, 119);
            padding: 10px 0;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 25px;
            font-weight: bold;
            font-size: 18px;
        }

        nav a:hover {
            text-decoration: underline;
            color: black;
        }

        .container {
            padding: 80px 20px;
            max-width: 600px;
            margin: 0 auto;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: flex-start;
            background-color: #444;
            padding: 30px;
            border-radius: 8px;
        }

        label {
            display: flex;
            flex-direction: column;
            width: 100%;
            font-weight: bold;
            color: white;
        }

        input {
            padding: 8px;
            font-size: 14px;
            margin-top: 5px;
            border-radius: 4px;
            border: none;
            width: 100%;
        }

        input[type="submit"] {
            background-color: rgb(84, 47, 119);
            color: white;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
        }

        input[type="submit"]:hover {
            background-color: rgb(66, 33, 100);
        }

        footer {
            margin-top: 40px;
            padding: 10px;
            background-color: rgb(0, 0, 0);
            color: white;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
        <h1>CST499 University Hub - Enrollment</h1>
    </header>

    <nav>
        <a href="/index.php">Landing Page</a>
    </nav>

    <div class="container">
        <p>Enroll as a New Student Below:</p>
        <form action="" method="post">
            <label>Email Address:
                <input type="email" name="email" required>
            </label>
            <label>Password:
                <input type="password" name="password" required>
            </label>
            <label>First Name:
                <input type="text" name="firstName" required>
            </label>
            <label>Last Name:
                <input type="text" name="lastName" required>
            </label>
            <label>Address:
                <input type="text" name="address" required>
            </label>
            <label>Phone Number:
                <input type="text" name="phone" required>
            </label>
            <label>Social Security Number:
                <input type="text" name="SSN" required>
            </label>
            <input type="submit" name="enroll" value="Enroll">
        </form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['enroll'])) {
    $Email_Address = $_POST['email'];
    $Password = $_POST['password'];
    $First_Name = $_POST['firstName'];
    $Last_Name = $_POST['lastName'];
    $Address = $_POST['address'];
    $Phone_Number = $_POST['phone'];
    $SSN = $_POST['SSN'];

    $id = uniqid();

    $db = new Database();
    $con = $db->connection;

    $stmt = $con->prepare("SELECT * FROM tblstudent WHERE Password = ?");
    $stmt->bind_param("s", $Password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<p style='color: red;'>Error: Password already exists. Please choose a unique one.</p>";
        $stmt->close();
    } else {
        $stmt->close();

        $stmt = $con->prepare("INSERT INTO tblstudent (id, Email_Address, Password, First_Name, Last_Name, Address, Phone_Number, SSN)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $id, $Email_Address, $Password, $First_Name, $Last_Name, $Address, $Phone_Number, $SSN);

        if ($stmt->execute()) {
            echo "<p style='color: lightgreen;'>Enrollment Successful</p>";
        } else {
            echo "<p style='color: red;'>Error: " . $stmt->error . "</p>";
        }

        $stmt->close();
    }
}
?>
    </div>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> CST499Wakim.</p>
    </footer>
</body>
</html>