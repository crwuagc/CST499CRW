<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - University Hub</title>
    <style>
        body {
            font-family: "Times New Roman", Times;
            background: rgb(32, 32, 32);
            margin: 0;
            padding: 0;
            font-size: 15px;
            color: white;
            text-align: center;
        }

        header {
            background-color: rgb(84, 47, 119);
            color: white;
            padding: 40px 0;
        }

        nav {
            background-color: rgb(84, 47, 119);
            padding: 10px 0;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 25px;
            font-weight: bold;
            font-size: 18px;
        }

        nav a:hover {
            text-decoration: underline;
            color: black;
        }

        .container {
            padding: 50px 20px;
        }

        footer {
            margin-top: 0px;
            padding: 10px;
            background-color: rgb(0, 0, 0);
            color: white;
            font-size: 14px;
        }

        .login-form {
            max-width: 400px;
            margin: 0 auto;
            background-color: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 8px;
        }

        .login-form input[type="text"],
        .login-form input[type="password"] {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 4px;
        }

        .login-form input[type="submit"] {
            background-color: rgb(84, 47, 119);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
        }

        .login-form input[type="submit"]:hover {
            background-color: rgb(64, 35, 90);
        }

        .error-message {
            color: red;
            font-weight: bold;
            margin: 10px 0;
        }

    </style>
</head>
<body>
    <header>
        <h1>CST499 University Hub - Login</h1>
    </header>
    <nav>
        <a href="/index.php">Landing Page</a>
    </nav>
    <div class="container">
        <div class="login-form">
            <h2>Login</h2>
            <p>Enter Student Email and Password.</p>

            <?php if (isset($_GET['error']) && $_GET['error'] == 1): ?>
                <div class="error-message">
                    Incorrect Email or Password. Please Try Again.
                </div>
            <?php endif; ?>

            <form action="authenticate.php" method="POST">
                <input type="text" name="email" placeholder="Email" required><br>
                <input type="password" name="password" placeholder="Password" required><br>
                <input type="submit" value="Login">
            </form>
        </div>
    </div>
    <footer>
        &copy; <?php echo date("Y"); ?> CST499Wakim.
    </footer>
</body>
</html>